"""金枢 FinTrust Agent 后端应用包。"""

__version__ = "0.1.0"
